# 📚 BookStore Management System

A full-stack book store management web app built with Node.js, Express, MongoDB, and EJS. Follows MVC architecture. Built as a college project — clean, practical, and easy to understand.

---

## Features

- Add new books with title, author, category, price, quantity, description, and cover image
- View all books in a modern card grid layout
- Edit any book's details (with optional image replacement)
- Delete books with a confirmation prompt
- Dashboard stats: total books, total stock, categories
- Responsive design — works on mobile too
- Dark editorial UI with smooth hover animations
- Image uploads handled via Multer

---

## Tech Stack

| Layer | Tech |
|-------|------|
| Backend | Node.js + Express.js |
| Database | MongoDB + Mongoose |
| Frontend | EJS Templates |
| Styling | Custom CSS (Bootstrap Icons) |
| File Upload | Multer |
| Dev Tool | Nodemon |

---

## Folder Structure

```
bookstore/
├── app.js                 # Entry point
├── config/
│   ├── db.js              # MongoDB connection
│   └── multer.js          # File upload config
├── controllers/
│   └── bookController.js  # All route logic
├── models/
│   └── Book.js            # Mongoose schema
├── routes/
│   └── bookRoutes.js      # Express routes
├── views/
│   ├── partials/
│   │   ├── header.ejs
│   │   └── footer.ejs
│   ├── index.ejs          # Home / all books
│   ├── add.ejs            # Add book form
│   ├── edit.ejs           # Edit book form
│   └── 404.ejs
├── public/
│   ├── css/style.css
│   └── js/main.js
├── uploads/               # Uploaded images stored here
├── package.json
└── README.md
```

---

## MongoDB Schema

```js
{
  title:       String  (required),
  author:      String  (required),
  category:    String  (required),
  price:       Number  (required),
  quantity:    Number  (required, default: 1),
  description: String,
  image:       String  // filename of uploaded image
}
```

---

## Setup & Run

### 1. Clone / download the project

```bash
git clone <repo-url>
cd bookstore
```

### 2. Install dependencies

```bash
npm install
```

### 3. Make sure MongoDB is running locally

```bash
# Start MongoDB (if using local install)
mongod
```

Or update the connection string in `config/db.js` to use MongoDB Atlas:

```js
// config/db.js
await mongoose.connect('mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/bookstore');
```

### 4. Run the app

```bash
# Development (with auto-restart)
npm run dev

# Production
npm start
```

### 5. Open in browser

```
http://localhost:3000
```

---

## Sample .env (optional)

You can optionally use a `.env` file:

```
PORT=3000
MONGO_URI=mongodb://localhost:27017/bookstore
```

And load it with `dotenv` in `app.js`.

---

## Screenshots

> _(Add screenshots here after running the project)_

| Page | Preview |
|------|---------|
| Home / All Books | `screenshots/home.png` |
| Add Book Form | `screenshots/add.png` |
| Edit Book Form | `screenshots/edit.png` |

---

## Notes

- Uploaded images are stored in `/uploads/` folder
- Images are served at `/uploads/<filename>`
- Max image size: 5MB
- Supported formats: jpg, jpeg, png, gif, webp

---

Made with ☕ by a student who needed a CRUD project.
